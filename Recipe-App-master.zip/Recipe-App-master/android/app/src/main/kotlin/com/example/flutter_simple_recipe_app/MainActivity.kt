package com.example.flutter_simple_recipe_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
